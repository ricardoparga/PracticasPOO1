//By Ricardo Parga 3ro C
//Hora de inicio; 8:35
//Termino de practica; 8:48
public class Saludador{
		public void Saludar(){
			System.out.println("Hola Alumno de POO");
		}
}