public class PruebaSaludador{
	public static void main(String[] args) {
		Saludador alumno = new Saludador();
		alumno.Saludar();
	}
}